export declare const PACKAGE_VERSION = "6.0.0";
