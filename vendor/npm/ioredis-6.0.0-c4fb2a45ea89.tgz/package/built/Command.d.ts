/// <reference types="node" />
/// <reference types="node" />
import { Callback, Respondable, CommandParameter } from "./types";
import { ReplyContext, ReplyTransformer } from "./replyTransformers";
export type ArgumentType = string | Buffer | number | (string | Buffer | number | any[])[];
interface CommandOptions {
    /**
     * Set the encoding of the reply, by default buffer will be returned.
     */
    replyEncoding?: BufferEncoding | null;
    errorStack?: Error;
    keyPrefix?: string;
    /**
     * Force the command to be readOnly so it will also execute on slaves
     */
    readOnly?: boolean;
}
type ArgumentTransformer = (args: any[]) => any[];
export interface CommandNameFlags {
    VALID_IN_SUBSCRIBER_MODE: [
        "subscribe",
        "psubscribe",
        "unsubscribe",
        "punsubscribe",
        "ssubscribe",
        "sunsubscribe",
        "ping",
        "quit"
    ];
    VALID_IN_MONITOR_MODE: ["monitor", "auth"];
    ENTER_SUBSCRIBER_MODE: ["subscribe", "psubscribe", "ssubscribe"];
    EXIT_SUBSCRIBER_MODE: ["unsubscribe", "punsubscribe", "sunsubscribe"];
    WILL_DISCONNECT: ["quit"];
    HANDSHAKE_COMMANDS: [
        "auth",
        "hello",
        "select",
        "client",
        "readonly",
        "info"
    ];
    IGNORE_RECONNECT_ON_ERROR: ["client"];
    BLOCKING_COMMANDS: [
        "blpop",
        "brpop",
        "brpoplpush",
        "blmove",
        "blmovem",
        "bzpopmin",
        "bzpopmax",
        "bzmpop",
        "blmpop",
        "xread",
        "xreadgroup"
    ];
    LAST_ARG_TIMEOUT_COMMANDS: [
        "blpop",
        "brpop",
        "brpoplpush",
        "blmove",
        "bzpopmin",
        "bzpopmax"
    ];
    FIRST_ARG_TIMEOUT_COMMANDS: ["bzmpop", "blmpop"];
    BLOCK_OPTION_COMMANDS: ["xread", "xreadgroup"];
}
/**
 * Command instance
 *
 * It's rare that you need to create a Command instance yourself.
 *
 * ```js
 * var infoCommand = new Command('info', null, function (err, result) {
 *   console.log('result', result);
 * });
 *
 * redis.sendCommand(infoCommand);
 *
 * // When no callback provided, Command instance will have a `promise` property,
 * // which will resolve/reject with the result of the command.
 * var getCommand = new Command('get', ['foo']);
 * getCommand.promise.then(function (result) {
 *   console.log('result', result);
 * });
 * ```
 */
export default class Command implements Respondable {
    name: string;
    static FLAGS: {
        [key in keyof CommandNameFlags]: CommandNameFlags[key];
    };
    private static flagMap?;
    private static _transformer;
    /**
     * Check whether the command has the flag
     */
    static checkFlag<T extends keyof CommandNameFlags>(flagName: T, commandName: string): commandName is CommandNameFlags[T][number];
    static setArgumentTransformer(name: string, func: ArgumentTransformer): void;
    static setReplyTransformer(name: string, func: ReplyTransformer): void;
    private static getFlagMap;
    ignore?: boolean;
    isReadOnly?: boolean;
    args: CommandParameter[];
    inTransaction: boolean;
    pipelineIndex?: number;
    isTraced: boolean;
    isResolved: boolean;
    isSettled: boolean;
    reject: (err: Error) => void;
    resolve: (result: any) => void;
    promise: Promise<any>;
    private replyEncoding;
    private protocol;
    private replyMapping;
    private errorStack;
    private bufferMode;
    private callback;
    private transformed;
    private _commandTimeoutTimer?;
    private _blockingTimeoutTimer?;
    private _blockingDeadline?;
    private slot?;
    private keys?;
    /**
     * Creates an instance of Command.
     * @param name Command name
     * @param args An array of command arguments
     * @param options
     * @param callback The callback that handles the response.
     * If omit, the response will be handled via Promise
     */
    constructor(name: string, args?: Array<ArgumentType>, options?: CommandOptions, callback?: Callback);
    getSlot(): number;
    getKeys(): Array<string | Buffer>;
    setReplyContext(context: ReplyContext | null | undefined): void;
    /**
     * Convert command to writable buffer or string
     */
    toWritable(_socket: object): string | Buffer;
    stringifyArguments(): void;
    /**
     * Convert buffer/buffer[] to string/string[],
     * and apply reply transformer.
     */
    transformReply(result: Buffer | Buffer[]): string | string[] | Buffer | Buffer[];
    /**
     * Set the wait time before terminating the attempt to execute a command
     * and generating an error.
     */
    setTimeout(ms: number): void;
    /**
     * Set a timeout for blocking commands.
     * When the timeout expires, the command resolves with null (matching Redis behavior).
     * This handles the case of undetectable network failures (e.g., docker network disconnect)
     * where the TCP connection becomes a zombie and no close event fires.
     */
    setBlockingTimeout(ms: number): void;
    /**
     * Extract the blocking timeout from the command arguments.
     *
     * @returns The timeout in seconds, null for indefinite blocking (timeout of 0),
     *          or undefined if this is not a blocking command
     */
    extractBlockingTimeout(): number | null | undefined;
    /**
     * Clear the command and blocking timers
     */
    private _clearTimers;
    private initPromise;
    /**
     * Iterate through the command arguments that are considered keys.
     */
    private _iterateKeys;
    /**
     * Convert the value from buffer to the target encoding.
     */
    private _convertValue;
}
export {};
