"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MemoryStores = void 0;
const tslib_1 = require("../../../internal/tslib.js");
const resource_1 = require("../../../core/resource.js");
const MemoriesAPI = tslib_1.__importStar(require("./memories.js"));
const memories_1 = require("./memories.js");
const MemoryVersionsAPI = tslib_1.__importStar(require("./memory-versions.js"));
const memory_versions_1 = require("./memory-versions.js");
const pagination_1 = require("../../../core/pagination.js");
const headers_1 = require("../../../internal/headers.js");
const tracing_1 = require("../../../internal/tracing.js");
const path_1 = require("../../../internal/utils/path.js");
var MemoryStores = /* @__PURE__ */ (() => {
    class MemoryStores extends resource_1.APIResource {
        constructor() {
            super(...arguments);
            this.memories = new MemoriesAPI.Memories(this._client);
            this.memoryVersions = new MemoryVersionsAPI.MemoryVersions(this._client);
        }
        /**
         * Create a Memory Store
         *
         * @example
         * ```ts
         * const betaManagedAgentsMemoryStore =
         *   await client.beta.memoryStores.create({ name: 'x' });
         * ```
         */
        create(params, options) {
            const { betas, workspace_id, ...body } = params;
            return this._client.post('/v1/memory_stores', {
                body,
                ...options,
                headers: (0, headers_1.buildHeaders)([
                    {
                        'anthropic-beta': [...(betas ?? []), 'agent-memory-2026-07-22'].toString(),
                        ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                    },
                    options?.headers,
                ]),
                __qualifiers: { beta: 'true' },
                __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.memory_stores.create', options, {
                    route: '/v1/memory_stores',
                    createdIDAttribute: 'gen_ai.memory.store.id',
                }),
            });
        }
        /**
         * Retrieve a Memory Store
         *
         * @example
         * ```ts
         * const betaManagedAgentsMemoryStore =
         *   await client.beta.memoryStores.retrieve(
         *     'memory_store_id',
         *   );
         * ```
         */
        retrieve(memoryStoreID, params = {}, options) {
            const { betas, workspace_id } = params ?? {};
            return this._client.get((0, path_1.path) `/v1/memory_stores/${memoryStoreID}`, {
                ...options,
                headers: (0, headers_1.buildHeaders)([
                    {
                        'anthropic-beta': [...(betas ?? []), 'agent-memory-2026-07-22'].toString(),
                        ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                    },
                    options?.headers,
                ]),
                __qualifiers: { beta: 'true' },
                __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.memory_stores.retrieve', options, {
                    route: '/v1/memory_stores/{memory_store_id}',
                    attributes: { 'gen_ai.memory.store.id': memoryStoreID },
                }),
            });
        }
        /**
         * Update a Memory Store
         *
         * @example
         * ```ts
         * const betaManagedAgentsMemoryStore =
         *   await client.beta.memoryStores.update('memory_store_id');
         * ```
         */
        update(memoryStoreID, params, options) {
            const { betas, workspace_id, ...body } = params;
            return this._client.post((0, path_1.path) `/v1/memory_stores/${memoryStoreID}`, {
                body,
                ...options,
                headers: (0, headers_1.buildHeaders)([
                    {
                        'anthropic-beta': [...(betas ?? []), 'agent-memory-2026-07-22'].toString(),
                        ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                    },
                    options?.headers,
                ]),
                __qualifiers: { beta: 'true' },
                __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.memory_stores.update', options, {
                    route: '/v1/memory_stores/{memory_store_id}',
                    attributes: { 'gen_ai.memory.store.id': memoryStoreID },
                }),
            });
        }
        /**
         * List Memory Stores
         *
         * @example
         * ```ts
         * // Automatically fetches more pages as needed.
         * for await (const betaManagedAgentsMemoryStore of client.beta.memoryStores.list()) {
         *   // ...
         * }
         * ```
         */
        list(params = {}, options) {
            const { betas, workspace_id, ...query } = params ?? {};
            return this._client.getAPIList('/v1/memory_stores', (pagination_1.PageCursor), {
                query,
                ...options,
                headers: (0, headers_1.buildHeaders)([
                    {
                        'anthropic-beta': [...(betas ?? []), 'agent-memory-2026-07-22'].toString(),
                        ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                    },
                    options?.headers,
                ]),
                __qualifiers: { beta: 'true' },
                __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.memory_stores.list', options, {
                    route: '/v1/memory_stores',
                    queryParams: ['created_at[gte]', 'created_at[lte]', 'include_archived', 'limit', 'page'],
                }),
            });
        }
        /**
         * Delete a Memory Store
         *
         * @example
         * ```ts
         * const betaManagedAgentsDeletedMemoryStore =
         *   await client.beta.memoryStores.delete('memory_store_id');
         * ```
         */
        delete(memoryStoreID, params = {}, options) {
            const { betas, workspace_id } = params ?? {};
            return this._client.delete((0, path_1.path) `/v1/memory_stores/${memoryStoreID}`, {
                ...options,
                headers: (0, headers_1.buildHeaders)([
                    {
                        'anthropic-beta': [...(betas ?? []), 'agent-memory-2026-07-22'].toString(),
                        ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                    },
                    options?.headers,
                ]),
                __qualifiers: { beta: 'true' },
                __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.memory_stores.delete', options, {
                    route: '/v1/memory_stores/{memory_store_id}',
                    attributes: { 'gen_ai.memory.store.id': memoryStoreID },
                }),
            });
        }
        /**
         * Archive a Memory Store
         *
         * @example
         * ```ts
         * const betaManagedAgentsMemoryStore =
         *   await client.beta.memoryStores.archive('memory_store_id');
         * ```
         */
        archive(memoryStoreID, params = {}, options) {
            const { betas, workspace_id } = params ?? {};
            return this._client.post((0, path_1.path) `/v1/memory_stores/${memoryStoreID}/archive`, {
                ...options,
                headers: (0, headers_1.buildHeaders)([
                    {
                        'anthropic-beta': [...(betas ?? []), 'agent-memory-2026-07-22'].toString(),
                        ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                    },
                    options?.headers,
                ]),
                __qualifiers: { beta: 'true' },
                __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.memory_stores.archive', options, {
                    route: '/v1/memory_stores/{memory_store_id}/archive',
                    attributes: { 'gen_ai.memory.store.id': memoryStoreID },
                }),
            });
        }
    }
    MemoryStores.Memories = memories_1.Memories;
    MemoryStores.MemoryVersions = memory_versions_1.MemoryVersions;
    return MemoryStores;
})();
exports.MemoryStores = MemoryStores;
//# sourceMappingURL=memory-stores.js.map