"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MemoryVersions = void 0;
const resource_1 = require("../../../core/resource.js");
const pagination_1 = require("../../../core/pagination.js");
const headers_1 = require("../../../internal/headers.js");
const tracing_1 = require("../../../internal/tracing.js");
const path_1 = require("../../../internal/utils/path.js");
class MemoryVersions extends resource_1.APIResource {
    /**
     * Retrieve a Memory Version
     *
     * @example
     * ```ts
     * const betaManagedAgentsMemoryVersion =
     *   await client.beta.memoryStores.memoryVersions.retrieve(
     *     'memory_version_id',
     *     { memory_store_id: 'memory_store_id' },
     *   );
     * ```
     */
    retrieve(memoryVersionID, params, options) {
        const { memory_store_id, betas, workspace_id, ...query } = params;
        return this._client.get((0, path_1.path) `/v1/memory_stores/${memory_store_id}/memory_versions/${memoryVersionID}`, {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
                {
                    'anthropic-beta': [...(betas ?? []), 'agent-memory-2026-07-22'].toString(),
                    ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                },
                options?.headers,
            ]),
            __qualifiers: { beta: 'true' },
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.memory_stores.memory_versions.retrieve', options, {
                route: '/v1/memory_stores/{memory_store_id}/memory_versions/{memory_version_id}',
                queryParams: ['view'],
                attributes: {
                    'gen_ai.memory.store.id': memory_store_id,
                    'anthropic.memory_store.memory_version.id': memoryVersionID,
                },
            }),
        });
    }
    /**
     * List Memory Versions
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaManagedAgentsMemoryVersion of client.beta.memoryStores.memoryVersions.list(
     *   'memory_store_id',
     * )) {
     *   // ...
     * }
     * ```
     */
    list(memoryStoreID, params = {}, options) {
        const { betas, workspace_id, ...query } = params ?? {};
        return this._client.getAPIList((0, path_1.path) `/v1/memory_stores/${memoryStoreID}/memory_versions`, (pagination_1.PageCursor), {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
                {
                    'anthropic-beta': [...(betas ?? []), 'agent-memory-2026-07-22'].toString(),
                    ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                },
                options?.headers,
            ]),
            __qualifiers: { beta: 'true' },
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.memory_stores.memory_versions.list', options, {
                route: '/v1/memory_stores/{memory_store_id}/memory_versions',
                queryParams: [
                    'api_key_id',
                    'created_at[gte]',
                    'created_at[lte]',
                    'limit',
                    'memory_id',
                    'operation',
                    'page',
                    'service_account_id',
                    'session_id',
                    'view',
                ],
                attributes: { 'gen_ai.memory.store.id': memoryStoreID },
            }),
        });
    }
    /**
     * Redact a Memory Version
     *
     * @example
     * ```ts
     * const betaManagedAgentsMemoryVersion =
     *   await client.beta.memoryStores.memoryVersions.redact(
     *     'memory_version_id',
     *     { memory_store_id: 'memory_store_id' },
     *   );
     * ```
     */
    redact(memoryVersionID, params, options) {
        const { memory_store_id, betas, workspace_id } = params;
        return this._client.post((0, path_1.path) `/v1/memory_stores/${memory_store_id}/memory_versions/${memoryVersionID}/redact`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
                {
                    'anthropic-beta': [...(betas ?? []), 'agent-memory-2026-07-22'].toString(),
                    ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                },
                options?.headers,
            ]),
            __qualifiers: { beta: 'true' },
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.memory_stores.memory_versions.redact', options, {
                route: '/v1/memory_stores/{memory_store_id}/memory_versions/{memory_version_id}/redact',
                attributes: {
                    'gen_ai.memory.store.id': memory_store_id,
                    'anthropic.memory_store.memory_version.id': memoryVersionID,
                },
            }),
        });
    }
}
exports.MemoryVersions = MemoryVersions;
//# sourceMappingURL=memory-versions.js.map