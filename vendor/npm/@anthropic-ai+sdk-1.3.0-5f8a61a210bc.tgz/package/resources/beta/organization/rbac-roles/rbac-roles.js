"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RBACRoles = void 0;
const tslib_1 = require("../../../../internal/tslib.js");
const resource_1 = require("../../../../core/resource.js");
const PermissionsAPI = tslib_1.__importStar(require("./permissions.js"));
const permissions_1 = require("./permissions.js");
const pagination_1 = require("../../../../core/pagination.js");
const tracing_1 = require("../../../../internal/tracing.js");
const path_1 = require("../../../../internal/utils/path.js");
var RBACRoles = /* @__PURE__ */ (() => {
    class RBACRoles extends resource_1.APIResource {
        constructor() {
            super(...arguments);
            this.permissions = new PermissionsAPI.Permissions(this._client);
        }
        /**
         * Retrieve an RBAC Role by ID.
         *
         * The RBAC Roles API is available to Claude Enterprise organizations only.
         *
         * @example
         * ```ts
         * const betaRBACRole =
         *   await client.beta.organization.rbacRoles.retrieve(
         *     'rbac_role_id',
         *   );
         * ```
         */
        retrieve(rbacRoleID, options) {
            return this._client.get((0, path_1.path) `/v1/organizations/rbac_roles/${rbacRoleID}`, {
                ...options,
                __qualifiers: { beta: 'true' },
                __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.organization.rbac_roles.retrieve', options, {
                    route: '/v1/organizations/rbac_roles/{rbac_role_id}',
                    attributes: { 'anthropic.organization.rbac_role.id': rbacRoleID },
                }),
            });
        }
        /**
         * List RBAC Roles in the organization.
         *
         * The RBAC Roles API is available to Claude Enterprise organizations only.
         *
         * @example
         * ```ts
         * // Automatically fetches more pages as needed.
         * for await (const betaRBACRole of client.beta.organization.rbacRoles.list()) {
         *   // ...
         * }
         * ```
         */
        list(query = {}, options) {
            return this._client.getAPIList('/v1/organizations/rbac_roles', (pagination_1.PageCursor), {
                query,
                ...options,
                __qualifiers: { beta: 'true' },
                __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.organization.rbac_roles.list', options, {
                    route: '/v1/organizations/rbac_roles',
                    queryParams: ['limit', 'page'],
                }),
            });
        }
    }
    RBACRoles.Permissions = permissions_1.Permissions;
    return RBACRoles;
})();
exports.RBACRoles = RBACRoles;
//# sourceMappingURL=rbac-roles.js.map