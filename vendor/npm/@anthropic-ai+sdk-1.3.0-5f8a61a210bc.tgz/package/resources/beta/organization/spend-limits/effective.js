"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Effective = void 0;
const resource_1 = require("../../../../core/resource.js");
const pagination_1 = require("../../../../core/pagination.js");
const tracing_1 = require("../../../../internal/tracing.js");
class Effective extends resource_1.APIResource {
    /**
     * List each member's effective spend limit and period-to-date spend.
     *
     * Returns one row per (member, period) the member resolves a spend limit for, with
     * the `source` scope the spend limit was inherited from. Paginates by member, so a
     * member's periods never split across pages. Supported for Claude Enterprise
     * organizations only, not for Claude Console organizations.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaSpendSummary of client.beta.organization.spendLimits.effective.list()) {
     *   // ...
     * }
     * ```
     */
    list(query = {}, options) {
        return this._client.getAPIList('/v1/organizations/spend_limits/effective', (pagination_1.PageCursor), {
            query,
            ...options,
            __qualifiers: { beta: 'true' },
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.organization.spend_limits.effective.list', options, {
                route: '/v1/organizations/spend_limits/effective',
                queryParams: ['limit', 'page', 'period', 'user_ids'],
            }),
        });
    }
}
exports.Effective = Effective;
//# sourceMappingURL=effective.js.map