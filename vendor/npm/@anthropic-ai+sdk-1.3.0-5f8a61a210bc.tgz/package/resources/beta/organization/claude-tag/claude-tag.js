"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClaudeTag = void 0;
const tslib_1 = require("../../../../internal/tslib.js");
const resource_1 = require("../../../../core/resource.js");
const SlackChannelsAPI = tslib_1.__importStar(require("./slack-channels.js"));
const slack_channels_1 = require("./slack-channels.js");
const SlackWorkspacesAPI = tslib_1.__importStar(require("./slack-workspaces.js"));
const slack_workspaces_1 = require("./slack-workspaces.js");
const BundlesAPI = tslib_1.__importStar(require("./bundles/bundles.js"));
const bundles_1 = require("./bundles/bundles.js");
var ClaudeTag = /* @__PURE__ */ (() => {
    class ClaudeTag extends resource_1.APIResource {
        constructor() {
            super(...arguments);
            this.slackChannels = new SlackChannelsAPI.SlackChannels(this._client);
            this.slackWorkspaces = new SlackWorkspacesAPI.SlackWorkspaces(this._client);
            this.bundles = new BundlesAPI.Bundles(this._client);
        }
    }
    ClaudeTag.SlackChannels = slack_channels_1.SlackChannels;
    ClaudeTag.SlackWorkspaces = slack_workspaces_1.SlackWorkspaces;
    ClaudeTag.Bundles = bundles_1.Bundles;
    return ClaudeTag;
})();
exports.ClaudeTag = ClaudeTag;
//# sourceMappingURL=claude-tag.js.map