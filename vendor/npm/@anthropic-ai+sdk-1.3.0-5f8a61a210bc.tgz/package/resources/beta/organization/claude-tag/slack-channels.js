"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SlackChannels = void 0;
const resource_1 = require("../../../../core/resource.js");
const pagination_1 = require("../../../../core/pagination.js");
const headers_1 = require("../../../../internal/headers.js");
const tracing_1 = require("../../../../internal/tracing.js");
const path_1 = require("../../../../internal/utils/path.js");
class SlackChannels extends resource_1.APIResource {
    /**
     * Set a Slack channel up for Claude Tag and return it with its identifier. If the
     * channel is already set up, whether in claude.ai, by Claude's first use in it or
     * by an earlier request, the existing channel is returned, so the request can be
     * repeated. `settings`, when sent, is applied as an update applies it. Before a
     * channel is set up, Claude's Slack app confirms with Slack that the channel is in
     * the workspace, is not archived and is visible to the app; a channel that fails
     * the confirmation returns 404. Setting the channel up and applying `settings` are
     * two steps: when the second is refused, the response is the refusal, the channel
     * stays set up with every setting unset, and the error's
     * `details.slack_channel_id` holds the channel's identifier.
     *
     * @example
     * ```ts
     * const betaClaudeTagSlackChannel =
     *   await client.beta.organization.claudeTag.slackChannels.create(
     *     { slack: { channel_id: 'xx', workspace_id: 'xx' } },
     *   );
     * ```
     */
    create(params, options) {
        const { betas, ...body } = params;
        return this._client.post('/v1/organizations/claude_tag/slack_channels', {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
                { 'anthropic-beta': [...(betas ?? []), 'experimental-claude-tag-2026-10-21'].toString() },
                options?.headers,
            ]),
            __qualifiers: { beta: 'true' },
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.organization.claude_tag.slack_channels.create', options, {
                route: '/v1/organizations/claude_tag/slack_channels',
                createdIDAttribute: 'anthropic.organization.claude_tag.slack_channel.id',
            }),
        });
    }
    /**
     * Get one Slack channel and its settings. By default `settings` holds what the
     * channel itself stores: a setting that is null there is not set on the channel
     * and is inherited. With `include_inherited=true`, `settings` holds what applies
     * in the channel once the settings levels above it are taken into account, and the
     * request fails with 503 rather than resolve against a settings level that could
     * not be read. Either way `sources` names the settings level each value comes
     * from, so a caller tells the channel's own value from an inherited one by its
     * source, not by whether it is null.
     *
     * @example
     * ```ts
     * const betaClaudeTagSlackChannel =
     *   await client.beta.organization.claudeTag.slackChannels.retrieve(
     *     'slch_01SvpyRQK3nN6eH9uhRA7n1q',
     *   );
     * ```
     */
    retrieve(id, params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.get((0, path_1.path) `/v1/organizations/claude_tag/slack_channels/${id}`, {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
                { 'anthropic-beta': [...(betas ?? []), 'experimental-claude-tag-2026-10-21'].toString() },
                options?.headers,
            ]),
            __qualifiers: { beta: 'true' },
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.organization.claude_tag.slack_channels.retrieve', options, {
                route: '/v1/organizations/claude_tag/slack_channels/{id}',
                queryParams: ['include_inherited'],
                attributes: { 'anthropic.organization.claude_tag.slack_channel.id': id },
            }),
        });
    }
    /**
     * Change the settings a Slack channel stores. The update is partial: a setting
     * left out is unchanged, and a setting sent as null is cleared, so the channel
     * inherits it. If any value is refused, no setting in the request is stored. A
     * group direct message takes no settings and returns 400.
     *
     * @example
     * ```ts
     * const betaClaudeTagSlackChannel =
     *   await client.beta.organization.claudeTag.slackChannels.update(
     *     'slch_01SvpyRQK3nN6eH9uhRA7n1q',
     *     { settings: {} },
     *   );
     * ```
     */
    update(id, params, options) {
        const { betas, ...body } = params;
        return this._client.post((0, path_1.path) `/v1/organizations/claude_tag/slack_channels/${id}`, {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
                { 'anthropic-beta': [...(betas ?? []), 'experimental-claude-tag-2026-10-21'].toString() },
                options?.headers,
            ]),
            __qualifiers: { beta: 'true' },
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.organization.claude_tag.slack_channels.update', options, {
                route: '/v1/organizations/claude_tag/slack_channels/{id}',
                attributes: { 'anthropic.organization.claude_tag.slack_channel.id': id },
            }),
        });
    }
    /**
     * List the set-up Slack channels of one Slack workspace, newest first by
     * `created_at`. A channel that is not set up is not listed: Slack holds the full
     * list of a workspace's channels. Pass `slack_channel_id` as well to look one
     * channel up by its Slack identifiers: `data` then holds that channel, or is empty
     * when it is not set up, and `limit` and `page` are ignored. A workspace that the
     * organization owns only through a Slack Enterprise Grid returns 404 until it is
     * set up. With `include_inherited=true` each channel's `settings` holds what
     * applies in it, and the request fails with 503 rather than resolve against a
     * settings level that could not be read. A `page` cursor resumes only a request
     * with the same `include_inherited`.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaClaudeTagSlackChannel of client.beta.organization.claudeTag.slackChannels.list(
     *   { slack_workspace_id: 'slack_workspace_id' },
     * )) {
     *   // ...
     * }
     * ```
     */
    list(params, options) {
        const { betas, ...query } = params;
        return this._client.getAPIList('/v1/organizations/claude_tag/slack_channels', (pagination_1.PageCursor), {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
                { 'anthropic-beta': [...(betas ?? []), 'experimental-claude-tag-2026-10-21'].toString() },
                options?.headers,
            ]),
            __qualifiers: { beta: 'true' },
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.organization.claude_tag.slack_channels.list', options, {
                route: '/v1/organizations/claude_tag/slack_channels',
                queryParams: ['include_inherited', 'limit', 'page', 'slack_channel_id', 'slack_workspace_id'],
            }),
        });
    }
    /**
     * Remove a Slack channel from Claude Tag. This deletes the channel's stored
     * settings and its Bundle Targets at once, and then, in the background, the
     * channel's sessions and their transcripts, its memory, its routines and the
     * artifacts published from it. None of it can be restored. The channel in Slack
     * and its messages are unchanged. The request is refused with 400 and
     * `error.details.error_code` `slack_channel_enabled` while `enabled` resolves to
     * `true` for the channel, as a read with `include_inherited=true` returns it: set
     * `enabled` to `false` on the channel first. This guards against removing a
     * channel in use by mistake; it is not a way to keep Claude out, because the
     * removal deletes the channel's own `enabled: false` with its other settings,
     * after which the channel inherits again and Claude's next use of it can set it up
     * anew with a new identifier. The identifier returns 404 as soon as the request
     * returns, so a repeated removal returns 404. A group direct message returns 400,
     * and so does a channel that holds configuration this API does not manage.
     *
     * @example
     * ```ts
     * const betaClaudeTagDeletedSlackChannel =
     *   await client.beta.organization.claudeTag.slackChannels.delete(
     *     'slch_01SvpyRQK3nN6eH9uhRA7n1q',
     *   );
     * ```
     */
    delete(id, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.delete((0, path_1.path) `/v1/organizations/claude_tag/slack_channels/${id}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
                { 'anthropic-beta': [...(betas ?? []), 'experimental-claude-tag-2026-10-21'].toString() },
                options?.headers,
            ]),
            __qualifiers: { beta: 'true' },
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.organization.claude_tag.slack_channels.delete', options, {
                route: '/v1/organizations/claude_tag/slack_channels/{id}',
                attributes: { 'anthropic.organization.claude_tag.slack_channel.id': id },
            }),
        });
    }
}
exports.SlackChannels = SlackChannels;
//# sourceMappingURL=slack-channels.js.map