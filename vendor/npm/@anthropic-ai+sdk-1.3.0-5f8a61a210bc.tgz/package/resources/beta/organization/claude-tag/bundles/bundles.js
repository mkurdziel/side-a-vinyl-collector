"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Bundles = void 0;
const tslib_1 = require("../../../../../internal/tslib.js");
const resource_1 = require("../../../../../core/resource.js");
const TargetsAPI = tslib_1.__importStar(require("./targets.js"));
const targets_1 = require("./targets.js");
const pagination_1 = require("../../../../../core/pagination.js");
const headers_1 = require("../../../../../internal/headers.js");
const tracing_1 = require("../../../../../internal/tracing.js");
const path_1 = require("../../../../../internal/utils/path.js");
var Bundles = /* @__PURE__ */ (() => {
    class Bundles extends resource_1.APIResource {
        constructor() {
            super(...arguments);
            this.targets = new TargetsAPI.Targets(this._client);
        }
        /**
         * Get one Bundle. What the Bundle grants (connectors, repositories and
         * credentials) is never returned.
         *
         * @example
         * ```ts
         * const betaClaudeTagBundle =
         *   await client.beta.organization.claudeTag.bundles.retrieve(
         *     'capp_011CZkZjLP1cWxj5EtMmdgbq',
         *   );
         * ```
         */
        retrieve(bundleID, params = {}, options) {
            const { betas } = params ?? {};
            return this._client.get((0, path_1.path) `/v1/organizations/claude_tag/bundles/${bundleID}`, {
                ...options,
                headers: (0, headers_1.buildHeaders)([
                    { 'anthropic-beta': [...(betas ?? []), 'experimental-claude-tag-2026-10-21'].toString() },
                    options?.headers,
                ]),
                __qualifiers: { beta: 'true' },
                __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.organization.claude_tag.bundles.retrieve', options, {
                    route: '/v1/organizations/claude_tag/bundles/{bundle_id}',
                    attributes: { 'anthropic.organization.claude_tag.bundle.id': bundleID },
                }),
            });
        }
        /**
         * List the organization's Bundles, newest first by `created_at`. A Bundle that
         * Claude Tag manages for itself is not listed.
         *
         * @example
         * ```ts
         * // Automatically fetches more pages as needed.
         * for await (const betaClaudeTagBundle of client.beta.organization.claudeTag.bundles.list()) {
         *   // ...
         * }
         * ```
         */
        list(params = {}, options) {
            const { betas, ...query } = params ?? {};
            return this._client.getAPIList('/v1/organizations/claude_tag/bundles', (pagination_1.PageCursor), {
                query,
                ...options,
                headers: (0, headers_1.buildHeaders)([
                    { 'anthropic-beta': [...(betas ?? []), 'experimental-claude-tag-2026-10-21'].toString() },
                    options?.headers,
                ]),
                __qualifiers: { beta: 'true' },
                __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.organization.claude_tag.bundles.list', options, {
                    route: '/v1/organizations/claude_tag/bundles',
                    queryParams: ['limit', 'page'],
                }),
            });
        }
    }
    Bundles.Targets = targets_1.Targets;
    return Bundles;
})();
exports.Bundles = Bundles;
//# sourceMappingURL=bundles.js.map