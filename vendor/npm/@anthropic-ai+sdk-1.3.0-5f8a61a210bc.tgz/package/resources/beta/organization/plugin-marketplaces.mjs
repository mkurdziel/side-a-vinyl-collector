import { APIResource } from "../../../core/resource.mjs";
import { PageCursor } from "../../../core/pagination.mjs";
import { buildHeaders } from "../../../internal/headers.mjs";
import { startApiCallSpan } from "../../../internal/tracing.mjs";
import { multipartFormRequestOptions } from "../../../internal/uploads.mjs";
import { path } from "../../../internal/utils/path.mjs";
export class PluginMarketplaces extends APIResource {
    /**
     * Retrieve a plugin marketplace by ID.
     *
     * **Accepted credentials:** an Admin API key with the `read:plugins` or
     * `read:org_audit` scope, or a Compliance Access Key with the
     * `read:compliance_org_data` scope.
     *
     * Every request must include the beta header
     * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
     * exactly as if the endpoint did not exist. The Plugins API is in beta and is
     * available to Claude Enterprise organizations only. It is not available to Claude
     * Platform (Claude Console) organizations, or to organizations with HIPAA
     * readiness enabled.
     *
     * @example
     * ```ts
     * const betaPluginMarketplace =
     *   await client.beta.organization.pluginMarketplaces.retrieve(
     *     'marketplace_id',
     *   );
     * ```
     */
    retrieve(marketplaceID, params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.get(path `/v1/organizations/plugin_marketplaces/${marketplaceID}`, {
            query,
            ...options,
            headers: buildHeaders([
                { 'anthropic-beta': [...(betas ?? []), 'ce-plugins-2026-09-01'].toString() },
                options?.headers,
            ]),
            __qualifiers: { beta: 'true' },
            __span: startApiCallSpan(this._client, 'anthropic.organization.plugin_marketplaces.retrieve', options, {
                route: '/v1/organizations/plugin_marketplaces/{marketplace_id}',
                queryParams: ['organization_id'],
                attributes: { 'anthropic.organization.plugin_marketplace.id': marketplaceID },
            }),
        });
    }
    /**
     * Set the default installation setting of one of the organization's own plugin
     * marketplaces. Every Plugin in it without a setting of its own gets this default
     * as its organization-wide setting, including Plugins added later.
     *
     * Pass it as `default_installation_preference`. A member's personal marketplace
     * cannot be updated here (403).
     *
     * **Accepted credentials:** an Admin API key with the `write:plugins` scope.
     *
     * Every request must include the beta header
     * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
     * exactly as if the endpoint did not exist. The Plugins API is in beta and is
     * available to Claude Enterprise organizations only. It is not available to Claude
     * Platform (Claude Console) organizations, or to organizations with HIPAA
     * readiness enabled.
     *
     * @example
     * ```ts
     * const betaPluginMarketplace =
     *   await client.beta.organization.pluginMarketplaces.update(
     *     'marketplace_id',
     *     { default_installation_preference: 'available' },
     *   );
     * ```
     */
    update(marketplaceID, params, options) {
        const { betas, ...body } = params;
        return this._client.post(path `/v1/organizations/plugin_marketplaces/${marketplaceID}`, {
            body,
            ...options,
            headers: buildHeaders([
                { 'anthropic-beta': [...(betas ?? []), 'ce-plugins-2026-09-01'].toString() },
                options?.headers,
            ]),
            __qualifiers: { beta: 'true' },
            __span: startApiCallSpan(this._client, 'anthropic.organization.plugin_marketplaces.update', options, {
                route: '/v1/organizations/plugin_marketplaces/{marketplace_id}',
                attributes: { 'anthropic.organization.plugin_marketplace.id': marketplaceID },
            }),
        });
    }
    /**
     * List the plugin marketplaces Plugins live in, newest first: the organization's
     * own and its members' personal ones.
     *
     * Plugin marketplaces are created, connected to a repository and deleted in
     * claude.ai, not through this API. The organization's library marketplace, the
     * organization-owned `manual` marketplace that uploads go to when no marketplace
     * is named, is created the first time something is put in it and is listed from
     * then on.
     *
     * **Accepted credentials:** an Admin API key with the `read:plugins` or
     * `read:org_audit` scope, or a Compliance Access Key with the
     * `read:compliance_org_data` scope.
     *
     * Every request must include the beta header
     * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
     * exactly as if the endpoint did not exist. The Plugins API is in beta and is
     * available to Claude Enterprise organizations only. It is not available to Claude
     * Platform (Claude Console) organizations, or to organizations with HIPAA
     * readiness enabled.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaPluginMarketplace of client.beta.organization.pluginMarketplaces.list()) {
     *   // ...
     * }
     * ```
     */
    list(params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.getAPIList('/v1/organizations/plugin_marketplaces', (PageCursor), {
            query,
            ...options,
            headers: buildHeaders([
                { 'anthropic-beta': [...(betas ?? []), 'ce-plugins-2026-09-01'].toString() },
                options?.headers,
            ]),
            __qualifiers: { beta: 'true' },
            __span: startApiCallSpan(this._client, 'anthropic.organization.plugin_marketplaces.list', options, {
                route: '/v1/organizations/plugin_marketplaces',
                queryParams: ['limit', 'organization_id', 'owner_type', 'page', 'source'],
            }),
        });
    }
    /**
     * Check whether a plugin marketplace, uploaded as a `.zip` of the marketplace
     * directory, would synchronize into claude.ai, without connecting or storing it.
     *
     * To check a public GitHub repository instead, use Validate Plugin Marketplace
     * Repository.
     *
     * The report says whether `marketplace.json` is well-formed, which plugins a
     * synchronization would skip and why, and which plugins would synchronize only in
     * part, with some files left out. An archive that cannot be read as a marketplace
     * is reported, not refused: the response is a report with `valid: false`. Plugin
     * sources outside the marketplace are fetched anonymously from GitHub, so a
     * private one is reported as not found or as needing a GitHub sign-in; a source on
     * any other host is not fetched here, and the report notes that it will be checked
     * when the marketplace actually synchronizes.
     *
     * Nothing is recorded on the Compliance API activity feed.
     *
     * For a worked example, see
     * [Validate marketplace content](/docs/en/manage-claude/plugins-api#validate-marketplace-content)
     * in the Plugins API guide.
     *
     * **Accepted credentials:** an Admin API key with the `read:plugins` or
     * `write:plugins` scope; `read:org_audit` and `read:compliance_org_data` do not
     * grant it.
     *
     * Every request must include the beta header
     * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
     * exactly as if the endpoint did not exist. The Plugins API is in beta and is
     * available to Claude Enterprise organizations only. It is not available to Claude
     * Platform (Claude Console) organizations, or to organizations with HIPAA
     * readiness enabled.
     *
     * @example
     * ```ts
     * const betaPluginMarketplaceValidationReport =
     *   await client.beta.organization.pluginMarketplaces.validateArchive(
     *     { archive: fs.createReadStream('path/to/file') },
     *   );
     * ```
     */
    validateArchive(params, options) {
        const { betas, ...body } = params;
        return this._client.post('/v1/organizations/plugin_marketplaces/validate_archive', multipartFormRequestOptions({
            body,
            ...options,
            headers: buildHeaders([
                { 'anthropic-beta': [...(betas ?? []), 'ce-plugins-2026-09-01'].toString() },
                options?.headers,
            ]),
            __qualifiers: { beta: 'true' },
            __span: startApiCallSpan(this._client, 'anthropic.organization.plugin_marketplaces.validate_archive', options, { route: '/v1/organizations/plugin_marketplaces/validate_archive' }),
        }, this._client));
    }
    /**
     * Check whether a plugin marketplace held in a public GitHub repository would
     * synchronize into claude.ai, without connecting or storing it.
     *
     * To check a `.zip` of the marketplace directory instead, use Validate Plugin
     * Marketplace Archive.
     *
     * The report says whether `marketplace.json` is well-formed, which plugins a
     * synchronization would skip and why, and which plugins would synchronize only in
     * part, with some files left out. A repository that is missing, private, or has no
     * such branch or commit is reported, not refused: the response is a report with
     * `valid: false`. Plugin sources outside the marketplace are fetched anonymously
     * from GitHub, so a private one is reported as not found or as needing a GitHub
     * sign-in; a source on any other host is not fetched here, and the report notes
     * that it will be checked when the marketplace actually synchronizes.
     *
     * Nothing is recorded on the Compliance API activity feed.
     *
     * For a worked example, see
     * [Validate marketplace content](/docs/en/manage-claude/plugins-api#validate-marketplace-content)
     * in the Plugins API guide.
     *
     * **Accepted credentials:** an Admin API key with the `read:plugins` or
     * `write:plugins` scope; `read:org_audit` and `read:compliance_org_data` do not
     * grant it.
     *
     * Every request must include the beta header
     * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
     * exactly as if the endpoint did not exist. The Plugins API is in beta and is
     * available to Claude Enterprise organizations only. It is not available to Claude
     * Platform (Claude Console) organizations, or to organizations with HIPAA
     * readiness enabled.
     *
     * @example
     * ```ts
     * const betaPluginMarketplaceValidationReport =
     *   await client.beta.organization.pluginMarketplaces.validateRepository(
     *     {
     *       repository_url:
     *         'https://github.com/example-org/example-marketplace',
     *     },
     *   );
     * ```
     */
    validateRepository(params, options) {
        const { betas, ...body } = params;
        return this._client.post('/v1/organizations/plugin_marketplaces/validate_repository', {
            body,
            ...options,
            headers: buildHeaders([
                { 'anthropic-beta': [...(betas ?? []), 'ce-plugins-2026-09-01'].toString() },
                options?.headers,
            ]),
            __qualifiers: { beta: 'true' },
            __span: startApiCallSpan(this._client, 'anthropic.organization.plugin_marketplaces.validate_repository', options, { route: '/v1/organizations/plugin_marketplaces/validate_repository' }),
        });
    }
}
//# sourceMappingURL=plugin-marketplaces.mjs.map