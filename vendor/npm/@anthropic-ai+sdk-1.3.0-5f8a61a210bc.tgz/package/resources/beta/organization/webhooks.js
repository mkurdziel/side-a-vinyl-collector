"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Webhooks = void 0;
const resource_1 = require("../../../core/resource.js");
const pagination_1 = require("../../../core/pagination.js");
const headers_1 = require("../../../internal/headers.js");
const tracing_1 = require("../../../internal/tracing.js");
const path_1 = require("../../../internal/utils/path.js");
class Webhooks extends resource_1.APIResource {
    /**
     * Create an organization webhook endpoint.
     *
     * An organization webhook endpoint belongs to the organization rather than to one
     * of its workspaces. An organization can have at most 32 organization webhook
     * endpoints, enabled or disabled.
     *
     * The response includes the endpoint's signing secret. No read returns it, so
     * store it when you receive it.
     *
     * Every request must include the beta header
     * `anthropic-beta: webhooks-2026-10-07`. A request without it returns `404`,
     * exactly as if this API did not exist. Anthropic turns organization webhook
     * endpoints on for each organization; until yours is on, requests also return
     * `404`. Organization webhook endpoints are in beta and are not available to
     * organizations with HIPAA readiness enabled.
     *
     * @example
     * ```ts
     * const betaNewOrganizationWebhookEndpoint =
     *   await client.beta.organization.webhooks.create({
     *     enabled_events: [
     *       'user_profile.enforcement_action_opened',
     *     ],
     *     url: 'x',
     *   });
     * ```
     */
    create(params, options) {
        const { betas, ...body } = params;
        return this._client.post('/v1/organizations/webhooks', {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
                { 'anthropic-beta': [...(betas ?? []), 'webhooks-2026-10-07'].toString() },
                options?.headers,
            ]),
            __qualifiers: { beta: 'true' },
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.organization.webhooks.create', options, {
                route: '/v1/organizations/webhooks',
                createdIDAttribute: 'anthropic.organization.webhook.id',
            }),
        });
    }
    /**
     * Retrieve an organization webhook endpoint by ID.
     *
     * Every request must include the beta header
     * `anthropic-beta: webhooks-2026-10-07`. A request without it returns `404`,
     * exactly as if this API did not exist. Anthropic turns organization webhook
     * endpoints on for each organization; until yours is on, requests also return
     * `404`. Organization webhook endpoints are in beta and are not available to
     * organizations with HIPAA readiness enabled.
     *
     * @example
     * ```ts
     * const betaOrganizationWebhookEndpoint =
     *   await client.beta.organization.webhooks.retrieve(
     *     'webhook_endpoint_id',
     *   );
     * ```
     */
    retrieve(webhookEndpointID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.get((0, path_1.path) `/v1/organizations/webhooks/${webhookEndpointID}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
                { 'anthropic-beta': [...(betas ?? []), 'webhooks-2026-10-07'].toString() },
                options?.headers,
            ]),
            __qualifiers: { beta: 'true' },
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.organization.webhooks.retrieve', options, {
                route: '/v1/organizations/webhooks/{webhook_endpoint_id}',
                attributes: { 'anthropic.organization.webhook.id': webhookEndpointID },
            }),
        });
    }
    /**
     * Update an organization webhook endpoint. Only the fields you send are changed.
     *
     * Every request must include the beta header
     * `anthropic-beta: webhooks-2026-10-07`. A request without it returns `404`,
     * exactly as if this API did not exist. Anthropic turns organization webhook
     * endpoints on for each organization; until yours is on, requests also return
     * `404`. Organization webhook endpoints are in beta and are not available to
     * organizations with HIPAA readiness enabled.
     *
     * @example
     * ```ts
     * const betaOrganizationWebhookEndpoint =
     *   await client.beta.organization.webhooks.update(
     *     'webhook_endpoint_id',
     *   );
     * ```
     */
    update(webhookEndpointID, params, options) {
        const { betas, ...body } = params;
        return this._client.post((0, path_1.path) `/v1/organizations/webhooks/${webhookEndpointID}`, {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
                { 'anthropic-beta': [...(betas ?? []), 'webhooks-2026-10-07'].toString() },
                options?.headers,
            ]),
            __qualifiers: { beta: 'true' },
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.organization.webhooks.update', options, {
                route: '/v1/organizations/webhooks/{webhook_endpoint_id}',
                attributes: { 'anthropic.organization.webhook.id': webhookEndpointID },
            }),
        });
    }
    /**
     * List the organization's webhook endpoints.
     *
     * An organization webhook endpoint belongs to the organization rather than to one
     * of its workspaces. The list does not include webhook endpoints that belong to a
     * workspace.
     *
     * Every request must include the beta header
     * `anthropic-beta: webhooks-2026-10-07`. A request without it returns `404`,
     * exactly as if this API did not exist. Anthropic turns organization webhook
     * endpoints on for each organization; until yours is on, requests also return
     * `404`. Organization webhook endpoints are in beta and are not available to
     * organizations with HIPAA readiness enabled.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaOrganizationWebhookEndpoint of client.beta.organization.webhooks.list()) {
     *   // ...
     * }
     * ```
     */
    list(params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.getAPIList('/v1/organizations/webhooks', (pagination_1.Page), {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
                { 'anthropic-beta': [...(betas ?? []), 'webhooks-2026-10-07'].toString() },
                options?.headers,
            ]),
            __qualifiers: { beta: 'true' },
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.organization.webhooks.list', options, {
                route: '/v1/organizations/webhooks',
                queryParams: ['after_id', 'before_id', 'limit', 'order'],
            }),
        });
    }
    /**
     * Delete an organization webhook endpoint.
     *
     * Every request must include the beta header
     * `anthropic-beta: webhooks-2026-10-07`. A request without it returns `404`,
     * exactly as if this API did not exist. Anthropic turns organization webhook
     * endpoints on for each organization; until yours is on, requests also return
     * `404`. Organization webhook endpoints are in beta and are not available to
     * organizations with HIPAA readiness enabled.
     *
     * @example
     * ```ts
     * const betaDeletedOrganizationWebhookEndpoint =
     *   await client.beta.organization.webhooks.delete(
     *     'webhook_endpoint_id',
     *   );
     * ```
     */
    delete(webhookEndpointID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.delete((0, path_1.path) `/v1/organizations/webhooks/${webhookEndpointID}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
                { 'anthropic-beta': [...(betas ?? []), 'webhooks-2026-10-07'].toString() },
                options?.headers,
            ]),
            __qualifiers: { beta: 'true' },
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.organization.webhooks.delete', options, {
                route: '/v1/organizations/webhooks/{webhook_endpoint_id}',
                attributes: { 'anthropic.organization.webhook.id': webhookEndpointID },
            }),
        });
    }
    /**
     * Replace an organization webhook endpoint's signing secret. The old secret stops
     * working immediately. The new secret is returned only in this response.
     *
     * Every request must include the beta header
     * `anthropic-beta: webhooks-2026-10-07`. A request without it returns `404`,
     * exactly as if this API did not exist. Anthropic turns organization webhook
     * endpoints on for each organization; until yours is on, requests also return
     * `404`. Organization webhook endpoints are in beta and are not available to
     * organizations with HIPAA readiness enabled.
     *
     * @example
     * ```ts
     * const betaOrganizationWebhookEndpointSigningSecret =
     *   await client.beta.organization.webhooks.regenerateSigningSecret(
     *     'webhook_endpoint_id',
     *   );
     * ```
     */
    regenerateSigningSecret(webhookEndpointID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.post((0, path_1.path) `/v1/organizations/webhooks/${webhookEndpointID}/regenerate_signing_secret`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
                { 'anthropic-beta': [...(betas ?? []), 'webhooks-2026-10-07'].toString() },
                options?.headers,
            ]),
            __qualifiers: { beta: 'true' },
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.organization.webhooks.regenerate_signing_secret', options, {
                route: '/v1/organizations/webhooks/{webhook_endpoint_id}/regenerate_signing_secret',
                attributes: { 'anthropic.organization.webhook.id': webhookEndpointID },
            }),
        });
    }
}
exports.Webhooks = Webhooks;
//# sourceMappingURL=webhooks.js.map