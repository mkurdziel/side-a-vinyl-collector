"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Versions = void 0;
const resource_1 = require("../../../../core/resource.js");
const pagination_1 = require("../../../../core/pagination.js");
const headers_1 = require("../../../../internal/headers.js");
const tracing_1 = require("../../../../internal/tracing.js");
const uploads_1 = require("../../../../internal/uploads.js");
const path_1 = require("../../../../internal/utils/path.js");
class Versions extends resource_1.APIResource {
    /**
     * Add a version to an organization-owned Plugin by uploading the new version's
     * files; it becomes the version served to members unless the Plugin's served
     * version has been pinned.
     *
     * The upload is the same `multipart/form-data` as creating a Plugin: the version's
     * files (`files`, each part sent as `files[]`) and optional `release_notes`. The
     * uploaded manifest's `name` must equal the Plugin's `name`. Returns the stored
     * version; read the Plugin back to see which version it serves.
     *
     * Only a Plugin in a `manual` marketplace takes uploads; a Plugin synchronized
     * from a repository gets its versions from the repository. When the Plugin is in
     * the organization's library marketplace, a version that adds a skill with the
     * name of an organization skill (a skill an administrator uploaded for the whole
     * organization in claude.ai) is refused with a 409: `error_code`
     * `skill_name_taken`, with that name in `details.skill_name`. A 503 with
     * `error_code` `registration_pending` means the version was stored but is not yet
     * usable; a later version create on the Plugin completes it.
     *
     * For a worked example, see
     * [Create a version](/docs/en/manage-claude/plugins-api#create-a-version) in the
     * Plugins API guide.
     *
     * **Accepted credentials:** an Admin API key with the `write:plugins` scope.
     *
     * Every request must include the beta header
     * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
     * exactly as if the endpoint did not exist. The Plugins API is in beta and is
     * available to Claude Enterprise organizations only. It is not available to Claude
     * Platform (Claude Console) organizations, or to organizations with HIPAA
     * readiness enabled.
     *
     * @example
     * ```ts
     * const betaPluginVersion =
     *   await client.beta.organization.plugins.versions.create(
     *     'plugin_id',
     *     { files: [fs.createReadStream('path/to/file')] },
     *   );
     * ```
     */
    create(pluginID, params, options) {
        const { betas, ...body } = params;
        return this._client.post((0, path_1.path) `/v1/organizations/plugins/${pluginID}/versions`, (0, uploads_1.multipartFormRequestOptions)({
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
                { 'anthropic-beta': [...(betas ?? []), 'ce-plugins-2026-09-01'].toString() },
                options?.headers,
            ]),
            __qualifiers: { beta: 'true' },
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.organization.plugins.versions.create', options, {
                route: '/v1/organizations/plugins/{plugin_id}/versions',
                attributes: { 'anthropic.organization.plugin.id': pluginID },
                createdIDAttribute: 'anthropic.organization.plugin.version.id',
            }),
        }, this._client));
    }
    /**
     * Retrieve one version of a Plugin by its ID, or the Plugin's newest version.
     *
     * **Accepted credentials:** an Admin API key with the `read:plugins` or
     * `read:org_audit` scope, or a Compliance Access Key with the
     * `read:compliance_org_data` scope.
     *
     * Every request must include the beta header
     * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
     * exactly as if the endpoint did not exist. The Plugins API is in beta and is
     * available to Claude Enterprise organizations only. It is not available to Claude
     * Platform (Claude Console) organizations, or to organizations with HIPAA
     * readiness enabled.
     *
     * @example
     * ```ts
     * const betaPluginVersion =
     *   await client.beta.organization.plugins.versions.retrieve(
     *     'version',
     *     { plugin_id: 'plugin_id' },
     *   );
     * ```
     */
    retrieve(version, params, options) {
        const { plugin_id, betas, ...query } = params;
        return this._client.get((0, path_1.path) `/v1/organizations/plugins/${plugin_id}/versions/${version}`, {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
                { 'anthropic-beta': [...(betas ?? []), 'ce-plugins-2026-09-01'].toString() },
                options?.headers,
            ]),
            __qualifiers: { beta: 'true' },
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.organization.plugins.versions.retrieve', options, {
                route: '/v1/organizations/plugins/{plugin_id}/versions/{version}',
                queryParams: ['organization_id'],
                attributes: {
                    'anthropic.organization.plugin.id': plugin_id,
                    'anthropic.organization.plugin.version.id': version,
                },
            }),
        });
    }
    /**
     * List a Plugin's versions, newest first.
     *
     * The first item of the first page is the version the Plugin's `latest_version_id`
     * refers to.
     *
     * **Accepted credentials:** an Admin API key with the `read:plugins` or
     * `read:org_audit` scope, or a Compliance Access Key with the
     * `read:compliance_org_data` scope.
     *
     * Every request must include the beta header
     * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
     * exactly as if the endpoint did not exist. The Plugins API is in beta and is
     * available to Claude Enterprise organizations only. It is not available to Claude
     * Platform (Claude Console) organizations, or to organizations with HIPAA
     * readiness enabled.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaPluginVersion of client.beta.organization.plugins.versions.list(
     *   'plugin_id',
     * )) {
     *   // ...
     * }
     * ```
     */
    list(pluginID, params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.getAPIList((0, path_1.path) `/v1/organizations/plugins/${pluginID}/versions`, (pagination_1.PageCursor), {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
                { 'anthropic-beta': [...(betas ?? []), 'ce-plugins-2026-09-01'].toString() },
                options?.headers,
            ]),
            __qualifiers: { beta: 'true' },
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.organization.plugins.versions.list', options, {
                route: '/v1/organizations/plugins/{plugin_id}/versions',
                queryParams: ['limit', 'organization_id', 'page'],
                attributes: { 'anthropic.organization.plugin.id': pluginID },
            }),
        });
    }
    /**
     * Download one version's `.zip` archive, exactly as stored. Each download of a
     * Plugin from a member's personal plugin marketplace is recorded on the Compliance
     * API activity feed.
     *
     * The response body is the archive (`Content-Type: application/zip`), sent as an
     * attachment whose filename is derived from the Plugin's name; name saved files
     * from the IDs in the request path, since that filename is not unique.
     *
     * **Accepted credentials:** an Admin API key with the `read:plugins` or
     * `read:org_audit` scope, or a Compliance Access Key with the
     * `read:compliance_org_data` scope.
     *
     * Every read scope above (`read:plugins`, `read:org_audit`, and
     * `read:compliance_org_data`) can download the files of plugins in members'
     * personal marketplaces, including files that claude.ai's admin settings do not
     * show, and a `read:org_audit` or `read:compliance_org_data` key created for all
     * of your parent organization's linked organizations can do this in any
     * organization under it that has access to this API, by passing `organization_id`.
     * Each such download records a `claude_plugin_archive_accessed` event on the
     * Compliance API activity feed, identifying the key, the plugin, the version, and
     * the member. Downloads of organization-owned plugins are not recorded.
     *
     * Every request must include the beta header
     * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
     * exactly as if the endpoint did not exist. The Plugins API is in beta and is
     * available to Claude Enterprise organizations only. It is not available to Claude
     * Platform (Claude Console) organizations, or to organizations with HIPAA
     * readiness enabled.
     *
     * @example
     * ```ts
     * const response =
     *   await client.beta.organization.plugins.versions.download(
     *     'version',
     *     { plugin_id: 'plugin_id' },
     *   );
     *
     * const content = await response.blob();
     * console.log(content);
     * ```
     */
    download(version, params, options) {
        const { plugin_id, betas, ...query } = params;
        return this._client.get((0, path_1.path) `/v1/organizations/plugins/${plugin_id}/versions/${version}/content`, {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
                {
                    'anthropic-beta': [...(betas ?? []), 'ce-plugins-2026-09-01'].toString(),
                    Accept: 'application/binary',
                },
                options?.headers,
            ]),
            __qualifiers: { beta: 'true' },
            __binaryResponse: true,
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.organization.plugins.versions.download', options, {
                route: '/v1/organizations/plugins/{plugin_id}/versions/{version}/content',
                queryParams: ['organization_id'],
                attributes: {
                    'anthropic.organization.plugin.id': plugin_id,
                    'anthropic.organization.plugin.version.id': version,
                },
            }),
        });
    }
}
exports.Versions = Versions;
//# sourceMappingURL=versions.js.map