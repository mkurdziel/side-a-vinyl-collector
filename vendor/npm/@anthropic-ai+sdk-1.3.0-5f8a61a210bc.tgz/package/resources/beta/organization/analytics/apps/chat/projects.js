"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Projects = void 0;
const resource_1 = require("../../../../../../core/resource.js");
const pagination_1 = require("../../../../../../core/pagination.js");
const tracing_1 = require("../../../../../../internal/tracing.js");
class Projects extends resource_1.APIResource {
    /**
     * Get per-project activity for a given day, with cursor-based pagination.
     *
     * Returns activity metrics for each project in the organization, sorted by project
     * ID. Use `group_by[]` to break projects out per member or per RBAC group, and
     * `filter[]` to scope results; the parameter descriptions list the supported
     * dimensions. Available to organizations on a Claude Enterprise plan. Requires an
     * API key with the `read:analytics` scope.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaAnalyticsProjectActivity of client.beta.organization.analytics.apps.chat.projects.list()) {
     *   // ...
     * }
     * ```
     */
    list(query = {}, options) {
        return this._client.getAPIList('/v1/organizations/analytics/apps/chat/projects', (pagination_1.PageCursor), {
            query,
            ...options,
            __qualifiers: { beta: 'true' },
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.organization.analytics.apps.chat.projects.list', options, {
                route: '/v1/organizations/analytics/apps/chat/projects',
                queryParams: [
                    'date',
                    'ending_date',
                    'filter',
                    'group_by',
                    'limit',
                    'order',
                    'order_by',
                    'page',
                    'starting_date',
                ],
            }),
        });
    }
}
exports.Projects = Projects;
//# sourceMappingURL=projects.js.map