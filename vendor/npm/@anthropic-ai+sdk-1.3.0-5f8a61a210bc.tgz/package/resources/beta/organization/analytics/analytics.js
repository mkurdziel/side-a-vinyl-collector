"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Analytics = void 0;
const tslib_1 = require("../../../../internal/tslib.js");
const resource_1 = require("../../../../core/resource.js");
const ArtifactsAPI = tslib_1.__importStar(require("./artifacts.js"));
const artifacts_1 = require("./artifacts.js");
const ConnectorsAPI = tslib_1.__importStar(require("./connectors.js"));
const connectors_1 = require("./connectors.js");
const CostAPI = tslib_1.__importStar(require("./cost.js"));
const cost_1 = require("./cost.js");
const CostReportAPI = tslib_1.__importStar(require("./cost-report.js"));
const cost_report_1 = require("./cost-report.js");
const PluginsAPI = tslib_1.__importStar(require("./plugins.js"));
const plugins_1 = require("./plugins.js");
const SkillsAPI = tslib_1.__importStar(require("./skills.js"));
const skills_1 = require("./skills.js");
const SummariesAPI = tslib_1.__importStar(require("./summaries.js"));
const summaries_1 = require("./summaries.js");
const UsageAPI = tslib_1.__importStar(require("./usage.js"));
const usage_1 = require("./usage.js");
const UsageReportAPI = tslib_1.__importStar(require("./usage-report.js"));
const usage_report_1 = require("./usage-report.js");
const UserCostReportAPI = tslib_1.__importStar(require("./user-cost-report.js"));
const user_cost_report_1 = require("./user-cost-report.js");
const UserUsageReportAPI = tslib_1.__importStar(require("./user-usage-report.js"));
const user_usage_report_1 = require("./user-usage-report.js");
const UsersAPI = tslib_1.__importStar(require("./users.js"));
const users_1 = require("./users.js");
const AppsAPI = tslib_1.__importStar(require("./apps/apps.js"));
const apps_1 = require("./apps/apps.js");
var Analytics = /* @__PURE__ */ (() => {
    class Analytics extends resource_1.APIResource {
        constructor() {
            super(...arguments);
            this.summaries = new SummariesAPI.Summaries(this._client);
            this.users = new UsersAPI.Users(this._client);
            this.apps = new AppsAPI.Apps(this._client);
            this.connectors = new ConnectorsAPI.Connectors(this._client);
            this.plugins = new PluginsAPI.Plugins(this._client);
            this.skills = new SkillsAPI.Skills(this._client);
            this.artifacts = new ArtifactsAPI.Artifacts(this._client);
            this.usage = new UsageAPI.Usage(this._client);
            this.cost = new CostAPI.Cost(this._client);
            this.usageReport = new UsageReportAPI.UsageReport(this._client);
            this.userUsageReport = new UserUsageReportAPI.UserUsageReport(this._client);
            this.costReport = new CostReportAPI.CostReport(this._client);
            this.userCostReport = new UserCostReportAPI.UserCostReport(this._client);
        }
    }
    Analytics.Summaries = summaries_1.Summaries;
    Analytics.Users = users_1.Users;
    Analytics.Apps = apps_1.Apps;
    Analytics.Connectors = connectors_1.Connectors;
    Analytics.Plugins = plugins_1.Plugins;
    Analytics.Skills = skills_1.Skills;
    Analytics.Artifacts = artifacts_1.Artifacts;
    Analytics.Usage = usage_1.Usage;
    Analytics.Cost = cost_1.Cost;
    Analytics.UsageReport = usage_report_1.UsageReport;
    Analytics.UserUsageReport = user_usage_report_1.UserUsageReport;
    Analytics.CostReport = cost_report_1.CostReport;
    Analytics.UserCostReport = user_cost_report_1.UserCostReport;
    return Analytics;
})();
exports.Analytics = Analytics;
//# sourceMappingURL=analytics.js.map