"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Connectors = void 0;
const resource_1 = require("../../../../core/resource.js");
const pagination_1 = require("../../../../core/pagination.js");
const tracing_1 = require("../../../../internal/tracing.js");
class Connectors extends resource_1.APIResource {
    /**
     * Get per-connector usage for a given day, with cursor-based pagination.
     *
     * Returns connector usage metrics for the organization, sorted by connector name.
     * Connector names are normalized from their various sources — for example,
     * "Atlassian MCP server" and "mcp-atlassian" both appear as "atlassian". Use
     * `group_by[]` to break usage out per member, per RBAC group, or per product
     * surface, and `filter[]` to scope results; the parameter descriptions list the
     * supported dimensions. Available to organizations on a Claude Enterprise plan.
     * Requires an API key with the `read:analytics` scope.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaAnalyticsConnectorActivity of client.beta.organization.analytics.connectors.list()) {
     *   // ...
     * }
     * ```
     */
    list(query = {}, options) {
        return this._client.getAPIList('/v1/organizations/analytics/connectors', (pagination_1.PageCursor), {
            query,
            ...options,
            __qualifiers: { beta: 'true' },
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.organization.analytics.connectors.list', options, {
                route: '/v1/organizations/analytics/connectors',
                queryParams: [
                    'date',
                    'ending_date',
                    'filter',
                    'group_by',
                    'limit',
                    'order',
                    'order_by',
                    'page',
                    'starting_date',
                ],
                contentQueryParams: ['filter'],
            }),
        });
    }
}
exports.Connectors = Connectors;
//# sourceMappingURL=connectors.js.map