"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Events = void 0;
const resource_1 = require("../../../../core/resource.js");
const pagination_1 = require("../../../../core/pagination.js");
const headers_1 = require("../../../../internal/headers.js");
const tracing_1 = require("../../../../internal/tracing.js");
const path_1 = require("../../../../internal/utils/path.js");
class Events extends resource_1.APIResource {
    /**
     * List Session Thread Events
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaManagedAgentsSessionEvent of client.beta.sessions.threads.events.list(
     *   'sthr_011CZkZVWa6oJjw1rgXZpnBt',
     *   { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
     * )) {
     *   // ...
     * }
     * ```
     */
    list(threadID, params, options) {
        const { session_id, betas, workspace_id, ...query } = params;
        return this._client.getAPIList((0, path_1.path) `/v1/sessions/${session_id}/threads/${threadID}/events`, (pagination_1.PageCursor), {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
                {
                    'anthropic-beta': [...(betas ?? []), 'managed-agents-2026-04-01'].toString(),
                    ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                },
                options?.headers,
            ]),
            __qualifiers: { beta: 'true' },
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.sessions.threads.events.list', options, {
                route: '/v1/sessions/{session_id}/threads/{thread_id}/events',
                queryParams: ['limit', 'page'],
                attributes: { 'anthropic.session.id': session_id, 'anthropic.session.thread.id': threadID },
            }),
        });
    }
    /**
     * Stream Session Thread Events
     *
     * @example
     * ```ts
     * const stream =
     *   await client.beta.sessions.threads.events.stream(
     *     'sthr_011CZkZVWa6oJjw1rgXZpnBt',
     *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
     *   );
     * for await (const betaManagedAgentsStreamSessionThreadEvents of stream) {
     *   // ...
     * }
     * ```
     */
    stream(threadID, params, options) {
        const { session_id, betas, workspace_id, ...query } = params;
        return this._client.get((0, path_1.path) `/v1/sessions/${session_id}/threads/${threadID}/stream`, {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
                {
                    'anthropic-beta': [...(betas ?? []), 'managed-agents-2026-04-01'].toString(),
                    ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                },
                options?.headers,
            ]),
            stream: true,
            __qualifiers: { beta: 'true' },
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.sessions.threads.events.stream', options, {
                route: '/v1/sessions/{session_id}/threads/{thread_id}/stream',
                queryParams: ['event_deltas'],
                attributes: { 'anthropic.session.id': session_id, 'anthropic.session.thread.id': threadID },
            }),
        });
    }
}
exports.Events = Events;
//# sourceMappingURL=events.js.map