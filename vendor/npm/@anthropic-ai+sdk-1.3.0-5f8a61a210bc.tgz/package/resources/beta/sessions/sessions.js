"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Sessions = void 0;
const tslib_1 = require("../../../internal/tslib.js");
const resource_1 = require("../../../core/resource.js");
const EventsAPI = tslib_1.__importStar(require("./events.js"));
const events_1 = require("./events.js");
const ResourcesAPI = tslib_1.__importStar(require("./resources.js"));
const resources_1 = require("./resources.js");
const ThreadsAPI = tslib_1.__importStar(require("./threads/threads.js"));
const threads_1 = require("./threads/threads.js");
const pagination_1 = require("../../../core/pagination.js");
const headers_1 = require("../../../internal/headers.js");
const tracing_1 = require("../../../internal/tracing.js");
const tracing_2 = require("../../../lib/internal/tracing.js");
const path_1 = require("../../../internal/utils/path.js");
var Sessions = /* @__PURE__ */ (() => {
    class Sessions extends resource_1.APIResource {
        constructor() {
            super(...arguments);
            this.events = new EventsAPI.Events(this._client);
            this.resources = new ResourcesAPI.Resources(this._client);
            this.threads = new ThreadsAPI.Threads(this._client);
        }
        /**
         * Create Session
         *
         * @example
         * ```ts
         * const betaManagedAgentsSession =
         *   await client.beta.sessions.create({
         *     agent: 'agent_011CZkYpogX7uDKUyvBTophP',
         *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
         *     initial_events: [
         *       {
         *         type: 'user.message',
         *         content: [
         *           {
         *             type: 'text',
         *             text: 'Where is my order #1234?',
         *           },
         *         ],
         *       },
         *     ],
         *   });
         * ```
         */
        create(params, options) {
            const { betas, workspace_id, ...body } = params;
            const headers = (0, headers_1.buildHeaders)([
                {
                    'anthropic-beta': [...(betas ?? []), 'managed-agents-2026-04-01'].toString(),
                    ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                },
                options?.headers,
            ]);
            const call = (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.sessions.create', options, {
                route: '/v1/sessions',
                attributes: {
                    // An `agent` that is no agent is for the API to refuse, not for this line to throw on.
                    'gen_ai.agent.id': typeof body.agent === 'object' ? body.agent?.id : body.agent,
                    'anthropic.session.environment.id': body.environment_id,
                },
                createdIDAttribute: 'anthropic.session.id',
            });
            const request = this._client.post('/v1/sessions', {
                body,
                ...options,
                headers,
                __qualifiers: { beta: 'true' },
                __span: call,
            });
            // Only a request with a span has a response to record.
            return call ?
                request._thenUnwrap((session) => {
                    (0, tracing_2.recordSessionsCreateResponse)(this._client, call, session);
                    return session;
                })
                : request;
        }
        /**
         * Get Session
         *
         * @example
         * ```ts
         * const betaManagedAgentsSession =
         *   await client.beta.sessions.retrieve(
         *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
         *   );
         * ```
         */
        retrieve(sessionID, params = {}, options) {
            const { betas, workspace_id } = params ?? {};
            return this._client.get((0, path_1.path) `/v1/sessions/${sessionID}`, {
                ...options,
                headers: (0, headers_1.buildHeaders)([
                    {
                        'anthropic-beta': [...(betas ?? []), 'managed-agents-2026-04-01'].toString(),
                        ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                    },
                    options?.headers,
                ]),
                __qualifiers: { beta: 'true' },
                __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.sessions.retrieve', options, {
                    route: '/v1/sessions/{session_id}',
                    attributes: { 'anthropic.session.id': sessionID },
                }),
            });
        }
        /**
         * Update Session
         *
         * @example
         * ```ts
         * const betaManagedAgentsSession =
         *   await client.beta.sessions.update(
         *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
         *   );
         * ```
         */
        update(sessionID, params, options) {
            const { betas, workspace_id, ...body } = params;
            return this._client.post((0, path_1.path) `/v1/sessions/${sessionID}`, {
                body,
                ...options,
                headers: (0, headers_1.buildHeaders)([
                    {
                        'anthropic-beta': [...(betas ?? []), 'managed-agents-2026-04-01'].toString(),
                        ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                    },
                    options?.headers,
                ]),
                __qualifiers: { beta: 'true' },
                __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.sessions.update', options, {
                    route: '/v1/sessions/{session_id}',
                    attributes: { 'anthropic.session.id': sessionID },
                }),
            });
        }
        /**
         * List Sessions
         *
         * @example
         * ```ts
         * // Automatically fetches more pages as needed.
         * for await (const betaManagedAgentsSession of client.beta.sessions.list()) {
         *   // ...
         * }
         * ```
         */
        list(params = {}, options) {
            const { betas, workspace_id, ...query } = params ?? {};
            return this._client.getAPIList('/v1/sessions', (pagination_1.BidirectionalPageCursor), {
                query,
                ...options,
                headers: (0, headers_1.buildHeaders)([
                    {
                        'anthropic-beta': [...(betas ?? []), 'managed-agents-2026-04-01'].toString(),
                        ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                    },
                    options?.headers,
                ]),
                __qualifiers: { beta: 'true' },
                __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.sessions.list', options, {
                    route: '/v1/sessions',
                    queryParams: [
                        'agent_id',
                        'agent_version',
                        'created_at[gt]',
                        'created_at[gte]',
                        'created_at[lt]',
                        'created_at[lte]',
                        'deployment_id',
                        'include_archived',
                        'limit',
                        'memory_store_id',
                        'order',
                        'page',
                        'statuses',
                    ],
                }),
            });
        }
        /**
         * Delete Session
         *
         * @example
         * ```ts
         * const betaManagedAgentsDeletedSession =
         *   await client.beta.sessions.delete(
         *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
         *   );
         * ```
         */
        delete(sessionID, params = {}, options) {
            const { betas, workspace_id } = params ?? {};
            return this._client.delete((0, path_1.path) `/v1/sessions/${sessionID}`, {
                ...options,
                headers: (0, headers_1.buildHeaders)([
                    {
                        'anthropic-beta': [...(betas ?? []), 'managed-agents-2026-04-01'].toString(),
                        ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                    },
                    options?.headers,
                ]),
                __qualifiers: { beta: 'true' },
                __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.sessions.delete', options, {
                    route: '/v1/sessions/{session_id}',
                    attributes: { 'anthropic.session.id': sessionID },
                }),
            });
        }
        /**
         * Archive Session
         *
         * @example
         * ```ts
         * const betaManagedAgentsSession =
         *   await client.beta.sessions.archive(
         *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
         *   );
         * ```
         */
        archive(sessionID, params = {}, options) {
            const { betas, workspace_id } = params ?? {};
            return this._client.post((0, path_1.path) `/v1/sessions/${sessionID}/archive`, {
                ...options,
                headers: (0, headers_1.buildHeaders)([
                    {
                        'anthropic-beta': [...(betas ?? []), 'managed-agents-2026-04-01'].toString(),
                        ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                    },
                    options?.headers,
                ]),
                __qualifiers: { beta: 'true' },
                __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.sessions.archive', options, {
                    route: '/v1/sessions/{session_id}/archive',
                    attributes: { 'anthropic.session.id': sessionID },
                }),
            });
        }
    }
    Sessions.Events = events_1.Events;
    Sessions.Resources = resources_1.Resources;
    Sessions.Threads = threads_1.Threads;
    return Sessions;
})();
exports.Sessions = Sessions;
//# sourceMappingURL=sessions.js.map