"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SessionToolRunner = exports.Events = void 0;
const resource_1 = require("../../../core/resource.js");
const pagination_1 = require("../../../core/pagination.js");
const headers_1 = require("../../../internal/headers.js");
const tracing_1 = require("../../../internal/tracing.js");
const path_1 = require("../../../internal/utils/path.js");
const SessionToolRunner_1 = require("../../../lib/tools/SessionToolRunner.js");
var Events = /* @__PURE__ */ (() => {
    class Events extends resource_1.APIResource {
        /**
         * List Events
         *
         * @example
         * ```ts
         * // Automatically fetches more pages as needed.
         * for await (const betaManagedAgentsSessionEvent of client.beta.sessions.events.list(
         *   'sesn_011CZkZAtmR3yMPDzynEDxu7',
         * )) {
         *   // ...
         * }
         * ```
         */
        list(sessionID, params = {}, options) {
            const { betas, workspace_id, ...query } = params ?? {};
            return this._client.getAPIList((0, path_1.path) `/v1/sessions/${sessionID}/events`, (pagination_1.PageCursor), {
                query,
                ...options,
                headers: (0, headers_1.buildHeaders)([
                    {
                        'anthropic-beta': [...(betas ?? []), 'managed-agents-2026-04-01'].toString(),
                        ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                    },
                    options?.headers,
                ]),
                __qualifiers: { beta: 'true' },
                __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.sessions.events.list', options, {
                    route: '/v1/sessions/{session_id}/events',
                    queryParams: [
                        'created_at[gt]',
                        'created_at[gte]',
                        'created_at[lt]',
                        'created_at[lte]',
                        'limit',
                        'order',
                        'page',
                        'types',
                    ],
                    attributes: { 'anthropic.session.id': sessionID },
                }),
            });
        }
        /**
         * Send Events
         *
         * @example
         * ```ts
         * const betaManagedAgentsSendSessionEvents =
         *   await client.beta.sessions.events.send(
         *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
         *     {
         *       events: [
         *         {
         *           content: [
         *             {
         *               text: 'Where is my order #1234?',
         *               type: 'text',
         *             },
         *           ],
         *           type: 'user.message',
         *         },
         *       ],
         *     },
         *   );
         * ```
         */
        send(sessionID, params, options) {
            const { betas, workspace_id, ...body } = params;
            return this._client.post((0, path_1.path) `/v1/sessions/${sessionID}/events`, {
                body,
                ...options,
                headers: (0, headers_1.buildHeaders)([
                    {
                        'anthropic-beta': [...(betas ?? []), 'managed-agents-2026-04-01'].toString(),
                        ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                    },
                    options?.headers,
                ]),
                __qualifiers: { beta: 'true' },
                __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.sessions.events.send', options, {
                    route: '/v1/sessions/{session_id}/events',
                    attributes: { 'anthropic.session.id': sessionID },
                }),
            });
        }
        /**
         * Stream Events
         *
         * @example
         * ```ts
         * const stream = await client.beta.sessions.events.stream(
         *   'sesn_011CZkZAtmR3yMPDzynEDxu7',
         * );
         * for await (const betaManagedAgentsStreamSessionEvents of stream) {
         *   // ...
         * }
         * ```
         */
        stream(sessionID, params = {}, options) {
            const { betas, workspace_id, ...query } = params ?? {};
            return this._client.get((0, path_1.path) `/v1/sessions/${sessionID}/events/stream`, {
                query,
                ...options,
                headers: (0, headers_1.buildHeaders)([
                    {
                        'anthropic-beta': [...(betas ?? []), 'managed-agents-2026-04-01'].toString(),
                        ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                    },
                    options?.headers,
                ]),
                stream: true,
                __qualifiers: { beta: 'true' },
                __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.sessions.events.stream', options, {
                    route: '/v1/sessions/{session_id}/events/stream',
                    queryParams: ['event_deltas'],
                    attributes: { 'anthropic.session.id': sessionID },
                }),
            });
        }
        /**
         * Attach to a session and dispatch every incoming `agent.tool_use` and
         * `agent.custom_tool_use` event to a local tool registry, sending the matching
         * result back (`user.tool_result` / `user.custom_tool_result`). The
         * sessions-side counterpart to `client.beta.messages.toolRunner`: yields one
         * entry per completed tool call so callers can observe each dispatch (and
         * `break` to abort cleanly).
         *
         * @example
         * ```ts
         * import { betaAgentToolset20260401 } from '@anthropic-ai/sdk/tools/agent-toolset/node';
         *
         * for await (const call of client.beta.sessions.events.toolRunner(work.data.id, {
         *   tools: [...betaAgentToolset20260401({ workdir }), myTool],
         * })) {
         *   console.log(`${call.name} -> ${call.isError ? 'error' : 'ok'}`);
         * }
         * ```
         */
        toolRunner(sessionID, opts) {
            return new SessionToolRunner_1.SessionToolRunner(sessionID, { ...opts, client: this._client });
        }
    }
    Events.SessionToolRunner = SessionToolRunner_1.SessionToolRunner;
    return Events;
})();
exports.Events = Events;
var SessionToolRunner_2 = require("../../../lib/tools/SessionToolRunner.js");
Object.defineProperty(exports, "SessionToolRunner", { enumerable: true, get: function () { return SessionToolRunner_2.SessionToolRunner; } });
//# sourceMappingURL=events.js.map