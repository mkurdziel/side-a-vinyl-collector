"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ActionURLs = void 0;
const resource_1 = require("../../core/resource.js");
const headers_1 = require("../../internal/headers.js");
const tracing_1 = require("../../internal/tracing.js");
const path_1 = require("../../internal/utils/path.js");
class ActionURLs extends resource_1.APIResource {
    /**
     * Create Action URL
     *
     * @example
     * ```ts
     * const userProfileActionURL =
     *   await client.userProfiles.actionURLs.create(
     *     'uprof_011CZkZCu8hGbp5mYRQgUmz9',
     *     { action: { type: 'enroll_end_user' } },
     *   );
     * ```
     */
    create(userProfileID, params, options) {
        const { workspace_id, ...body } = params;
        return this._client.post((0, path_1.path) `/v1/user_profiles/${userProfileID}/action_urls`, {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
                { ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined) },
                options?.headers,
            ]),
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.user_profiles.action_urls.create', options, {
                route: '/v1/user_profiles/{user_profile_id}/action_urls',
                attributes: { 'anthropic.user_profile.id': userProfileID },
            }),
        });
    }
}
exports.ActionURLs = ActionURLs;
//# sourceMappingURL=action-urls.js.map