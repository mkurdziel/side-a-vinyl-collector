"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RateLimits = void 0;
const resource_1 = require("../../core/resource.js");
const pagination_1 = require("../../core/pagination.js");
const tracing_1 = require("../../internal/tracing.js");
class RateLimits extends resource_1.APIResource {
    /**
     * List Messages API rate limits for your organization.
     *
     * Each entry corresponds to one rate-limit group (either a model family or an
     * API-surface category such as the Message Batches API or the web search tool) and
     * contains the set of limiter values that apply to it.
     *
     * When `limit` is omitted, every matching entry is returned in a single page; when
     * `limit` truncates the result, follow `next_page` to fetch the remaining entries.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const organizationRateLimit of client.organization.rateLimits.list()) {
     *   // ...
     * }
     * ```
     */
    list(query = {}, options) {
        return this._client.getAPIList('/v1/organizations/rate_limits', (pagination_1.PageCursor), {
            query,
            ...options,
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.organization.rate_limits.list', options, {
                route: '/v1/organizations/rate_limits',
                queryParams: ['group_type', 'limit', 'model', 'page'],
            }),
        });
    }
}
exports.RateLimits = RateLimits;
//# sourceMappingURL=rate-limits.js.map