"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.APIKeys = void 0;
const resource_1 = require("../../core/resource.js");
const pagination_1 = require("../../core/pagination.js");
const tracing_1 = require("../../internal/tracing.js");
const path_1 = require("../../internal/utils/path.js");
class APIKeys extends resource_1.APIResource {
    /**
     * Get API Key
     *
     * @example
     * ```ts
     * const apiKey = await client.organization.apiKeys.retrieve(
     *   'api_key_id',
     * );
     * ```
     */
    retrieve(apiKeyID, options) {
        return this._client.get((0, path_1.path) `/v1/organizations/api_keys/${apiKeyID}`, {
            ...options,
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.organization.api_keys.retrieve', options, {
                route: '/v1/organizations/api_keys/{api_key_id}',
                attributes: { 'anthropic.organization.api_key.id': apiKeyID },
            }),
        });
    }
    /**
     * Update API Key
     *
     * @example
     * ```ts
     * const apiKey = await client.organization.apiKeys.update(
     *   'api_key_id',
     * );
     * ```
     */
    update(apiKeyID, body, options) {
        return this._client.post((0, path_1.path) `/v1/organizations/api_keys/${apiKeyID}`, {
            body,
            ...options,
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.organization.api_keys.update', options, {
                route: '/v1/organizations/api_keys/{api_key_id}',
                attributes: { 'anthropic.organization.api_key.id': apiKeyID },
            }),
        });
    }
    /**
     * List API Keys
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const apiKey of client.organization.apiKeys.list()) {
     *   // ...
     * }
     * ```
     */
    list(query = {}, options) {
        return this._client.getAPIList('/v1/organizations/api_keys', (pagination_1.Page), {
            query,
            ...options,
            __span: (0, tracing_1.startApiCallSpan)(this._client, 'anthropic.organization.api_keys.list', options, {
                route: '/v1/organizations/api_keys',
                queryParams: ['after_id', 'before_id', 'created_by_user_id', 'limit', 'status', 'workspace_id'],
            }),
        });
    }
}
exports.APIKeys = APIKeys;
//# sourceMappingURL=api-keys.js.map