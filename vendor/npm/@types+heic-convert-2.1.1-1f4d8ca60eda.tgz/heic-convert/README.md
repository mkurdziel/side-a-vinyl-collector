# Installation
> `npm install --save @types/heic-convert`

# Summary
This package contains type definitions for heic-convert (https://github.com/catdad-experiments/heic-convert).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/heic-convert.

### Additional Details
 * Last updated: Wed, 03 Jun 2026 12:58:57 GMT
 * Dependencies: none

# Credits
These definitions were written by [Tregan](https://github.com/treemmett).
