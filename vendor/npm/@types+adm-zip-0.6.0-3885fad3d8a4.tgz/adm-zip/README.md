This is a stub types definition for @types/adm-zip (https://github.com/cthackers/adm-zip).

adm-zip provides its own type definitions, so you don't need @types/adm-zip installed!