"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.zodToJsonSchema = void 0;
const parseDef_1 = require("./parseDef.js");
const Refs_1 = require("./Refs.js");
const util_1 = require("./util.js");
function ownStrictRootSchema(schema, name, nameStrategy) {
    if (schema === null || typeof schema !== 'object') {
        throw new TypeError('Root schema must be a plain JSON-schema record');
    }
    // SAFETY: Object.getPrototypeOf returns an object or null; the following comparison permits only plain or null-prototype schemas.
    const prototype = Object.getPrototypeOf(schema);
    if (![null, Object.prototype].includes(prototype)) {
        throw new TypeError('Root schema must be a plain JSON-schema record');
    }
    const owned = {};
    for (const [key, descriptor] of Object.entries(Object.getOwnPropertyDescriptors(schema))) {
        if (!descriptor.enumerable) {
            continue;
        }
        if (!('value' in descriptor)) {
            throw new TypeError(`Root schema property '${key}' must be a data property`);
        }
        const value = descriptor.value;
        if (key === 'toJSON' && typeof value === 'function') {
            throw new TypeError("Root schema cannot contain a callable 'toJSON' property");
        }
        if (['undefined', 'function', 'symbol'].includes(typeof value)) {
            continue;
        }
        Object.defineProperty(owned, key, {
            configurable: true,
            enumerable: true,
            value,
            writable: true,
        });
    }
    const { type, nullable, $ref: reference } = owned;
    if (!['undefined', 'boolean'].includes(typeof nullable)) {
        throw new TypeError("Root schema 'nullable' must be a boolean");
    }
    if (type !== 'object' || nullable === true) {
        let actualType;
        if (typeof type === 'string') {
            actualType = nullable === true ? `${type},null` : type;
        }
        else if (Array.isArray(type)) {
            actualType = type.join(',');
        }
        throw new Error(`Root schema must have type: 'object' but got type: ${actualType ? `'${actualType}'` : 'undefined'}`);
    }
    if (reference !== undefined) {
        throw new Error("Root schema must be a concrete object and cannot contain '$ref'");
    }
    if (name !== undefined && nameStrategy !== 'duplicate-ref') {
        throw new Error("Root schema must have type: 'object' but got type: undefined");
    }
    // SAFETY: The copied schema preserves the validated JSON fields while taking ownership of the mutable converter result.
    return owned;
}
const zodToJsonSchema = (schema, options) => {
    const refs = (0, Refs_1.getRefs)(options);
    if (refs.openaiStrictMode) {
        refs.definitions = { ...refs.definitions };
    }
    let name;
    if (typeof options === 'string') {
        name = options;
    }
    else if (options?.nameStrategy !== 'title') {
        name = options?.name;
    }
    const parsed = (0, parseDef_1.parseDef)(schema._def, name === undefined
        ? refs
        : {
            ...refs,
            currentPath: [...refs.basePath, refs.definitionPath, name],
        }, refs.openaiStrictMode === true) ?? {};
    const main = refs.openaiStrictMode ? ownStrictRootSchema(parsed, name, refs.nameStrategy) : parsed;
    const title = refs.nameStrategy === 'title' ? refs.name : undefined;
    if (title !== undefined) {
        main.title = title;
    }
    const definitions = (() => {
        if ((0, util_1.isEmptyObj)(refs.definitions)) {
            return undefined;
        }
        const definitions = {};
        const processedDefinitions = new Set();
        // the call to `parseDef()` here might itself add more entries to `.definitions`
        // so we need to continually evaluate definitions until we've resolved all of them
        //
        // we have a generous iteration limit here to avoid blowing up the stack if there
        // are any bugs that would otherwise result in us iterating indefinitely
        for (let i = 0; i < 500; i++) {
            const newDefinitions = Object.entries(refs.definitions).filter(([key]) => !processedDefinitions.has(key));
            if (newDefinitions.length === 0) {
                break;
            }
            for (const [key, schema] of newDefinitions) {
                Object.defineProperty(definitions, key, {
                    value: (0, parseDef_1.parseDef)((0, util_1.zodDef)(schema), { ...refs, currentPath: [...refs.basePath, refs.definitionPath, key] }, true) ?? {},
                    enumerable: true,
                    configurable: true,
                    writable: true,
                });
                processedDefinitions.add(key);
            }
        }
        return definitions;
    })();
    let combined;
    if (name === undefined) {
        combined = definitions
            ? {
                ...main,
                [refs.definitionPath]: definitions,
            }
            : main;
    }
    else if (refs.nameStrategy === 'duplicate-ref') {
        combined = {
            ...main,
            ...(definitions || refs.seenRefs.size
                ? {
                    [refs.definitionPath]: {
                        ...definitions,
                        // only actually duplicate the schema definition if it was ever referenced
                        // otherwise the duplication is completely pointless
                        ...(refs.seenRefs.size ? { [name]: main } : undefined),
                    },
                }
                : undefined),
        };
    }
    else {
        combined = {
            $ref: [...(refs.$refStrategy === 'relative' ? [] : refs.basePath), refs.definitionPath, name].join('/'),
            [refs.definitionPath]: {
                ...definitions,
                [name]: main,
            },
        };
    }
    if (refs.target === 'jsonSchema7') {
        combined.$schema = 'http://json-schema.org/draft-07/schema#';
    }
    else if (refs.target === 'jsonSchema2019-09') {
        combined.$schema = 'https://json-schema.org/draft/2019-09/schema#';
    }
    return combined;
};
exports.zodToJsonSchema = zodToJsonSchema;
//# sourceMappingURL=zodToJsonSchema.js.map